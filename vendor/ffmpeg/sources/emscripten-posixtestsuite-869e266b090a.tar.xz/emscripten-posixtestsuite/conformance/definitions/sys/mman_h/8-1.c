/* 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 * Test that the header defines the POSIX_TYPED_MEM_ALLOCATE flag for 
 * posix_typed_mem_open()().
 *
 * @pt:TYM
 */

#include <sys/mman.h>

#ifndef POSIX_TYPED_MEM_ALLOCATE
#error POSIX_TYPED_MEM_ALLOCATE not defined
#endif
